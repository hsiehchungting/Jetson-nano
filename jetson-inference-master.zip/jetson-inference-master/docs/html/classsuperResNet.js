var classsuperResNet =
[
    [ "~superResNet", "classsuperResNet.html#a4867ff87e273b1d36605a881bc6f278c", null ],
    [ "superResNet", "classsuperResNet.html#a55e12611e1b5102def860ba93b3bb54c", null ],
    [ "GetInputHeight", "classsuperResNet.html#a742fd684d98f9f8d3aeaf3093535f3ef", null ],
    [ "GetInputWidth", "classsuperResNet.html#a9af57ed0d9bb28a82f1cad7a43648bea", null ],
    [ "GetOutputHeight", "classsuperResNet.html#a9f115dd878ad47bb12358ec52699e7ae", null ],
    [ "GetOutputWidth", "classsuperResNet.html#a9e1f7570a04374452a91528d665249ac", null ],
    [ "GetScaleFactor", "classsuperResNet.html#a6b4472f012b65414a2e9228f8eb747b9", null ],
    [ "UpscaleRGBA", "classsuperResNet.html#ac1248d34fa3b0e3c08c318088ed3c9d8", null ],
    [ "UpscaleRGBA", "classsuperResNet.html#a3bb1be3372403fdd29f78b88490854ff", null ]
];