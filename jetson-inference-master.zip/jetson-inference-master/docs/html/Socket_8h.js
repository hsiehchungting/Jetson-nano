var Socket_8h =
[
    [ "IP_ANY", "Socket_8h.html#aff78e91b6eed5ac391a5de7b6e62311e", null ],
    [ "IP_BROADCAST", "Socket_8h.html#a35513f0b657dc418e4108dec538299ff", null ],
    [ "IP_LOOPBACK", "Socket_8h.html#a64a65b271e90777a9531f8b34ebcdd51", null ],
    [ "SocketType", "group__network.html#gaa78c7398fa81f7f62aa233159d4d8d97", [
      [ "SOCKET_UDP", "group__network.html#ggaa78c7398fa81f7f62aa233159d4d8d97a180747545a72ff6d0fd0569e781aefd5", null ],
      [ "SOCKET_TCP", "group__network.html#ggaa78c7398fa81f7f62aa233159d4d8d97a2843397fd39bd96681bca78a8aa03096", null ]
    ] ]
];