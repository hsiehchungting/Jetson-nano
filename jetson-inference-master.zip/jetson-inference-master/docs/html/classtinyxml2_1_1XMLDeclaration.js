var classtinyxml2_1_1XMLDeclaration =
[
    [ "XMLDeclaration", "classtinyxml2_1_1XMLDeclaration.html#aef9586f2ce5df5feba74dde49a242b06", null ],
    [ "~XMLDeclaration", "classtinyxml2_1_1XMLDeclaration.html#a2a33ec2e9619f03687d048d24b2acaf5", null ],
    [ "Accept", "classtinyxml2_1_1XMLDeclaration.html#a5f376019fb34752eb248548f42f32045", null ],
    [ "ParseDeep", "classtinyxml2_1_1XMLDeclaration.html#a85e217f63cf47c65f81a44d360927cf7", null ],
    [ "ShallowClone", "classtinyxml2_1_1XMLDeclaration.html#a118d47518dd9e522644e42efa259aed7", null ],
    [ "ShallowEqual", "classtinyxml2_1_1XMLDeclaration.html#aa26b70011694e9b9e9480b929e9b78d6", null ],
    [ "ToDeclaration", "classtinyxml2_1_1XMLDeclaration.html#a159d8ac45865215e88059ea1e5b52fc5", null ],
    [ "ToDeclaration", "classtinyxml2_1_1XMLDeclaration.html#aa20c3315b18c3b88830dccf5c493259b", null ],
    [ "XMLDocument", "classtinyxml2_1_1XMLDeclaration.html#a4eee3bda60c60a30e4e8cd4ea91c4c6e", null ]
];