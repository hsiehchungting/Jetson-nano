var cudaCrop_8h =
[
    [ "cudaCrop", "group__crop.html#ga3d4c665ec3f71800a5099d4a438563d9", null ],
    [ "cudaCrop", "group__crop.html#ga867017394024f011012b6244115b07e7", null ],
    [ "cudaCrop", "group__crop.html#ga216a46406c3367ec40a531909c226090", null ],
    [ "cudaCrop", "group__crop.html#ga0e1e3d31e5622b599a6cd0eb138065d5", null ],
    [ "cudaCrop", "group__crop.html#gafa47a7df3f3f99e83e86cc6e780b9997", null ],
    [ "cudaCrop", "group__crop.html#ga4df9ac38e02cbab74f471c5f324980a2", null ],
    [ "cudaCrop", "group__crop.html#gacfbd48aaa32289a1322da72feb5311b8", null ]
];