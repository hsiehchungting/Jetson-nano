var RingBuffer_8inl =
[
    [ "__MULTITHREAD_RINGBUFFER_INLINE_H_", "RingBuffer_8inl.html#a0e8dd4ce00c60c0e7a74a08ffb6bf229", null ]
];