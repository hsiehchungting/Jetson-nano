var classtinyxml2_1_1MemPool =
[
    [ "MemPool", "classtinyxml2_1_1MemPool.html#a9101a0083d7370c85bd5aaaba7157f84", null ],
    [ "~MemPool", "classtinyxml2_1_1MemPool.html#ae55ad9e3faeca702e6ccbb38fdbcad72", null ],
    [ "Alloc", "classtinyxml2_1_1MemPool.html#a4f977b5fed752c0bbfe5295f469d6449", null ],
    [ "Clear", "classtinyxml2_1_1MemPool.html#a74fcdef9756917c8ae19fbbb4d658ed7", null ],
    [ "Free", "classtinyxml2_1_1MemPool.html#a49e3bfac2cba2ebd6776b31e571f64f7", null ],
    [ "ItemSize", "classtinyxml2_1_1MemPool.html#a0c518d49e3a94bde566f61e13b7240bb", null ],
    [ "SetTracked", "classtinyxml2_1_1MemPool.html#ac5804dd1387b2e4de5eef710076a0db1", null ]
];