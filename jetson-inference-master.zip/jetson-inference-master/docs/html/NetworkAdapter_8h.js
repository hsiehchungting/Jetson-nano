var NetworkAdapter_8h =
[
    [ "networkAdapters", "group__network.html#ga652cb8426e61fdd01babddb28ebcd85e", null ],
    [ "networkHostname", "group__network.html#ga5a28e78074e7cd736f75123c93a4a3f6", null ]
];