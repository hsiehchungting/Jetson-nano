var classvideoSource =
[
    [ "~videoSource", "classvideoSource.html#a2cae1095df64b7c61de77935b77032bb", null ],
    [ "videoSource", "classvideoSource.html#aaee65d53e3dfb3f4644608c0eebcf833", null ],
    [ "Capture", "classvideoSource.html#a872a7d5353b1cd97d02eb403ef8b57eb", null ],
    [ "Capture", "classvideoSource.html#a81bf11e5819d747eb9060a71e78fce75", null ],
    [ "Close", "classvideoSource.html#a19ed8f98e4ce28462296b498804005ae", null ],
    [ "GetFrameRate", "classvideoSource.html#a4e6ac667bd17a49cc94a6b16173a06ba", null ],
    [ "GetHeight", "classvideoSource.html#a6ca24054da683cae18b0bfad01dbf1d0", null ],
    [ "GetOptions", "classvideoSource.html#a7d423829515c5c91d132f476213e22bd", null ],
    [ "GetResource", "classvideoSource.html#a2052b0b41222c17e3d14964f10c3ffa6", null ],
    [ "GetType", "classvideoSource.html#a76f6f92cf40ad72e9d7f76538d583e37", null ],
    [ "GetWidth", "classvideoSource.html#a17f0c43e832d4de85a014b3aa4265732", null ],
    [ "IsStreaming", "classvideoSource.html#a0ce18fd4c3a8f934e7ec000f0d36b7e9", null ],
    [ "IsType", "classvideoSource.html#a0883cf58cd0d8d0c05fb192a01250b7a", null ],
    [ "IsType", "classvideoSource.html#ad3c1689db5baf2786099d2c0be075010", null ],
    [ "Open", "classvideoSource.html#aa7907ba2392b6ea5f747409d1bfbc18b", null ],
    [ "TypeToStr", "classvideoSource.html#a38909f4451ecdf3a2777aea3a088677e", null ],
    [ "mOptions", "classvideoSource.html#aa3c05686659fae747ff8709be2c9b445", null ],
    [ "mStreaming", "classvideoSource.html#a0907f7140f13fa75fef5b23a1f44b55b", null ]
];