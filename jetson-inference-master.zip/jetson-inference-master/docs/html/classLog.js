var classLog =
[
    [ "Level", "classLog.html#afb5d4c945d835d194a295461d752531e", [
      [ "SILENT", "classLog.html#afb5d4c945d835d194a295461d752531eabfeaf96ee427cb4a1e58079fe56d6659", null ],
      [ "ERROR", "classLog.html#afb5d4c945d835d194a295461d752531ea4cd0be82d98ca2a542adc75f2c826e5b", null ],
      [ "WARNING", "classLog.html#afb5d4c945d835d194a295461d752531ea3af89ac37cc3e24957e7901211345e96", null ],
      [ "SUCCESS", "classLog.html#afb5d4c945d835d194a295461d752531ead5214ff9471f920797b08c249706ab69", null ],
      [ "INFO", "classLog.html#afb5d4c945d835d194a295461d752531ea8ddc7ebe42544ebab9b3d6cf49ab33d8", null ],
      [ "VERBOSE", "classLog.html#afb5d4c945d835d194a295461d752531ea0763041e407c0324563ab6aff02b11ee", null ],
      [ "DEBUG", "classLog.html#afb5d4c945d835d194a295461d752531ea4e49113de847d4ce568b7f0d5647a715", null ],
      [ "DEFAULT", "classLog.html#afb5d4c945d835d194a295461d752531ea04f2e465914e7dd3f9c981ddd603e8e6", null ]
    ] ]
];