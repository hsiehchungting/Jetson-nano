var classtensorNet_1_1Profiler =
[
    [ "Profiler", "classtensorNet_1_1Profiler.html#a55a6fd3103bcd4a57379a90eff183617", null ],
    [ "reportLayerTime", "classtensorNet_1_1Profiler.html#a509ac9582f3e2f8f386363a0d43cc51c", null ],
    [ "timingAccumulator", "classtensorNet_1_1Profiler.html#a8784d561f96bfd5a02c2bf9554f0d773", null ]
];