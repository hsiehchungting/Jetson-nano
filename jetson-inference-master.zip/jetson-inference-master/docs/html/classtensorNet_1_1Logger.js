var classtensorNet_1_1Logger =
[
    [ "log", "classtensorNet_1_1Logger.html#a8bd9893db2a2344e5b601d6bd8f8619e", null ]
];