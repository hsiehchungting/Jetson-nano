var classtinyxml2_1_1MemPoolT =
[
    [ "ITEMS_PER_BLOCK", "classtinyxml2_1_1MemPoolT.html#a04cf45156e6f913f93972869ff8a1d94ab72c1e16d6626854c41feb19e60c54d1", null ],
    [ "MemPoolT", "classtinyxml2_1_1MemPoolT.html#ac8fa6dbb403f009cf9c8a33c6f2803b3", null ],
    [ "~MemPoolT", "classtinyxml2_1_1MemPoolT.html#a5fa4fee934a3df2b9e74282244d78390", null ],
    [ "Alloc", "classtinyxml2_1_1MemPoolT.html#a810fd2b0caf56b8b688e55f2768f96c7", null ],
    [ "Clear", "classtinyxml2_1_1MemPoolT.html#a22d595caa0e9d23aa080f49ca6475fdd", null ],
    [ "CurrentAllocs", "classtinyxml2_1_1MemPoolT.html#a445a6c80151ba6268b24ec62a7c84d74", null ],
    [ "Free", "classtinyxml2_1_1MemPoolT.html#a408ce0918e9d3d5e5e1cc4896944875f", null ],
    [ "ItemSize", "classtinyxml2_1_1MemPoolT.html#a54e4d9b343459ef1731314a99877ff35", null ],
    [ "SetTracked", "classtinyxml2_1_1MemPoolT.html#aee3c611215ae08cce41a940bf2763027", null ],
    [ "Trace", "classtinyxml2_1_1MemPoolT.html#a47eefbd934ef70d973ea41d41ab5f239", null ],
    [ "Untracked", "classtinyxml2_1_1MemPoolT.html#a3bcdc302ae15d2810e11192321a8f5f1", null ]
];