var glDisplay_8h =
[
    [ "eventHandler", "structglDisplay_1_1eventHandler.html", "structglDisplay_1_1eventHandler" ],
    [ "glGetDisplay", "group__OpenGL.html#ga6af68c26b9f5254ee676de8b6f332ad4", null ],
    [ "glGetNumDisplays", "group__OpenGL.html#ga80a5aa43c317714fe5bb41e1db6eb4c4", null ]
];