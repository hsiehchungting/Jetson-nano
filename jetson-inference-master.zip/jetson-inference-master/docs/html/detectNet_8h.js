var detectNet_8h =
[
    [ "Detection", "structdetectNet_1_1Detection.html", "structdetectNet_1_1Detection" ],
    [ "DETECTNET_DEFAULT_ALPHA", "group__detectNet.html#ga98aed3513105a81bd86361eef5423383", null ],
    [ "DETECTNET_DEFAULT_BBOX", "group__detectNet.html#gac8c52a38ffa041865ed71fd2ea806620", null ],
    [ "DETECTNET_DEFAULT_COVERAGE", "group__detectNet.html#ga1e79603783719e4a79f2c68f1ef47621", null ],
    [ "DETECTNET_DEFAULT_INPUT", "group__detectNet.html#gac824e329015dc8aed6e1112bfe21cb97", null ],
    [ "DETECTNET_DEFAULT_THRESHOLD", "group__detectNet.html#ga5de620e838c2ac9aec16c6de2977513f", null ],
    [ "DETECTNET_USAGE_STRING", "group__imageNet.html#gad5f43885a04689f10c6f9d297ab88a8d", null ]
];