var dir_49e56c817e5e54854c35e136979f97ca =
[
    [ "doc-groups.h", "doc-groups_8h.html", null ],
    [ "doc-pages.h", "doc-pages_8h.html", null ]
];