var cudaFilterMode_8h =
[
    [ "cudaDataFormat", "group__cudaFilter.html#ga66fe4a27e9fb59cd675d5deb12287195", [
      [ "FORMAT_HWC", "group__cudaFilter.html#gga66fe4a27e9fb59cd675d5deb12287195a4130db7b40bd34c9b4e91df46d37fc6a", null ],
      [ "FORMAT_CHW", "group__cudaFilter.html#gga66fe4a27e9fb59cd675d5deb12287195a4ccf6f5b6af6f76d13ef2aefd17ea51a", null ],
      [ "FORMAT_DEFAULT", "group__cudaFilter.html#gga66fe4a27e9fb59cd675d5deb12287195aa172a0e14adcf61d8fdc4df73a29dece", null ]
    ] ],
    [ "cudaFilterMode", "group__cudaFilter.html#ga25d4283643163befe99948d24cc53311", [
      [ "FILTER_POINT", "group__cudaFilter.html#gga25d4283643163befe99948d24cc53311a8928ed98915affb5c7514632a038daa6", null ],
      [ "FILTER_LINEAR", "group__cudaFilter.html#gga25d4283643163befe99948d24cc53311ad8e5de74ec16a7e07145b7c18c885094", null ]
    ] ],
    [ "cudaFilterModeFromStr", "group__cudaFilter.html#ga6a34c93022b23a55a5ae440a8ff7a247", null ],
    [ "cudaFilterModeToStr", "group__cudaFilter.html#gaf0051762a62125939ddbd5c38417f3ff", null ]
];