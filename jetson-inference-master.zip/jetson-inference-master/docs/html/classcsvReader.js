var classcsvReader =
[
    [ "csvReader", "classcsvReader.html#a78a1bbc9a537958955ea1c0ee292a68e", null ],
    [ "~csvReader", "classcsvReader.html#ad9bcff499b2864cba243ad89e71c0561", null ],
    [ "Close", "classcsvReader.html#a4fc10c933a0f7ae36a6bb892259f6cc2", null ],
    [ "GetDelimiters", "classcsvReader.html#aebd2551a4d24767f51ac7b2601af86c2", null ],
    [ "GetFilename", "classcsvReader.html#a88be003aa0289f664c204d65c78324cc", null ],
    [ "IsClosed", "classcsvReader.html#a046a28a013f4b0ef06487cb264d9d702", null ],
    [ "IsOpen", "classcsvReader.html#a2b9910b8116c3cb84b84dcfd828f13cd", null ],
    [ "Read", "classcsvReader.html#a04d0a5fc7425485a2aab823f42c983c1", null ],
    [ "Read", "classcsvReader.html#a1249df7246ae79204479cd2f8f72a420", null ],
    [ "Read", "classcsvReader.html#ae90ffbd5178a78da9be92ffa7399d798", null ],
    [ "Read", "classcsvReader.html#ab58d3d20b21ab6abf05adbd54b1c9175", null ],
    [ "SetDelimiters", "classcsvReader.html#a0a65b04b1268f0a36ff826a3abdfcfba", null ],
    [ "MaxLineLength", "classcsvReader.html#a033e3f7ca4e60c535ffe45085dc5ebe4", null ]
];