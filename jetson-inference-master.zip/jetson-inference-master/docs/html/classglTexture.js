var classglTexture =
[
    [ "~glTexture", "classglTexture.html#accb8f44543b92f75a137d768194a10d2", null ],
    [ "Bind", "classglTexture.html#a600cb151e484ef4497e50d96f9bfc2a9", null ],
    [ "Copy", "classglTexture.html#a0067ed41cdddd4371d5292586c25cecf", null ],
    [ "Copy", "classglTexture.html#ae3e8a8080be69e6170b5870b80bf6e9c", null ],
    [ "Copy", "classglTexture.html#a8c607bd04f6f27df58ad2fa50546fb60", null ],
    [ "GetFormat", "classglTexture.html#a24d1124dd9e3ee4a885037680e034d24", null ],
    [ "GetHeight", "classglTexture.html#a7e83b13ce1281d90a59c0cfca7f80834", null ],
    [ "GetID", "classglTexture.html#acba11f3282339fb2490c930177ec8562", null ],
    [ "GetSize", "classglTexture.html#a35ba15763a0a187bd4e103eda1e2ab5c", null ],
    [ "GetWidth", "classglTexture.html#ab4e7455f84741b4bc4601bd44df95063", null ],
    [ "Map", "classglTexture.html#a988866fe886ea2f07208e691a8b9a173", null ],
    [ "Render", "classglTexture.html#aacbc1ed68a99930b628b41d69997227e", null ],
    [ "Render", "classglTexture.html#a38103fc1ec96018601b21131db5144c9", null ],
    [ "Render", "classglTexture.html#ab449860cc3d739a6615d93f4a1764f20", null ],
    [ "Unbind", "classglTexture.html#a803c368b6a26675b4cc45b0aae47f9c3", null ],
    [ "Unmap", "classglTexture.html#aa2f21d5b0b9235bf53744ca71e258841", null ]
];