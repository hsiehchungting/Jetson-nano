var cudaGrayscale_8h =
[
    [ "cudaGray32ToGray8", "group__colorspace.html#gaeda6bd828034411d2957fefa9bc7c86c", null ],
    [ "cudaGray32ToRGB32", "group__colorspace.html#gabccc05a436032389da3f779e2cef98b4", null ],
    [ "cudaGray32ToRGB8", "group__colorspace.html#ga743d366c32e2dce7a9c57762fe525ca8", null ],
    [ "cudaGray32ToRGBA32", "group__colorspace.html#ga08968447eca071e40810d7e94e954375", null ],
    [ "cudaGray32ToRGBA8", "group__colorspace.html#gaf83b1be3204def331413fbf776aa3df3", null ],
    [ "cudaGray8ToGray32", "group__colorspace.html#gad2930b5da1adf112ea0d1fc2a4af6d7e", null ],
    [ "cudaGray8ToRGB32", "group__colorspace.html#ga8924f2b6d7b21c1c2f73e868e331592a", null ],
    [ "cudaGray8ToRGB8", "group__colorspace.html#gab37fe8aab37f309b90dc3b7df33fea22", null ],
    [ "cudaGray8ToRGBA32", "group__colorspace.html#gae3ecc5983890fc3846befedc01872a44", null ],
    [ "cudaGray8ToRGBA8", "group__colorspace.html#ga866ad8f2da224d6403ce6ea6a3e36f85", null ],
    [ "cudaRGB32ToGray32", "group__colorspace.html#gab4a99353101747d552ea86c56bda2c07", null ],
    [ "cudaRGB32ToGray8", "group__colorspace.html#ga05a851ab406d65c1f2f47e51ce771cbb", null ],
    [ "cudaRGB8ToGray32", "group__colorspace.html#ga7e65db0b95cd45e85296ba9db9f56621", null ],
    [ "cudaRGB8ToGray8", "group__colorspace.html#ga38d17b06ac4d2ffdb4b297cdda88d132", null ],
    [ "cudaRGBA32ToGray32", "group__colorspace.html#gac098220252c68f4adc86d38d781878c7", null ],
    [ "cudaRGBA32ToGray8", "group__colorspace.html#gae29c5520d17fdfe5e5cc046392cba334", null ],
    [ "cudaRGBA8ToGray32", "group__colorspace.html#ga76480ff68415cfc5ebe52ff4ee1dba18", null ],
    [ "cudaRGBA8ToGray8", "group__colorspace.html#ga1e4fbd03bd987c426abdfba35dc44e54", null ]
];