var classgstCamera =
[
    [ "~gstCamera", "classgstCamera.html#a1df842937128e70d8f140c65e88e783c", null ],
    [ "Capture", "classgstCamera.html#add77384dd73058543da2f1c722e00a30", null ],
    [ "Capture", "classgstCamera.html#afb2ece71edfbd233b8a84d93c8fbcab4", null ],
    [ "CaptureRGBA", "classgstCamera.html#a93371e3811a1956ff96c154fd1da23f2", null ],
    [ "Close", "classgstCamera.html#a8798df5c10fff5ecbaf2598816c94f55", null ],
    [ "GetType", "classgstCamera.html#a40bdf4c4b7675e33bf670df07918e9c6", null ],
    [ "Open", "classgstCamera.html#a28f4842c5648a253a1acee5276ac8486", null ]
];