var cudaColorspace_8h =
[
    [ "cudaConvertColor", "group__colorspace.html#ga2befa65dbc92689a36a367993d1ad673", null ],
    [ "cudaConvertColor", "group__colorspace.html#gab092814e4f699dec48343fcb67e69a88", null ]
];